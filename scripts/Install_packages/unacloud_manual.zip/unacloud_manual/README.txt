UnaCloud
Departamento de Ingenier�a de Sistemas y Computaci�n
Universidad de Los Andes
Colombia
https://github.com/UnaCloud

Manual Installation

This kind of installation package is designed to be distribuited and requires between 1 and 5 fives machines. You can allocate server components in different execution nodes or in the same one.

--Node for MySQL server

Install MySQL server
Validate communication with MySQL port.
Set database port in config.properties file.
Create a database.
Create an user with read and write privileges on database.
Set database name and user credentials in config.properties file.

--Node for RabbitMQ

Install RabbitMQ
Configure user with read and write queues privileges.
Validate communication with RabbitMQ port.
Set RabbitMQ port and user credentials in config.properties file.

--Node for CloudControl application

Install Java 7
Allow communication by TCP and UDP in two different ports of your preference.
Set ports in config.properties file.
Allocate config.properties file in path of your preference.
Set an environment variable PATH_CONFIG pointing to configuration file.
Allocate CloudControl.jar in path of your preference.
Execute file by command:
java �jar CloudControl.jar
Configure application to run when machine starts.

--Node for FileManager application

Install Java 7
Install and configure Tomcat 8
Allow communication by TCP in two different ports of your preference.
Allow communication by HTTP in configured port for Tomcat.
Allocate file FileManager.war in webapps Tomcat folder.
Create a folder which works as repository for virtual machine files.
Set ports, repository path, and URL in config.properties file.
Allocate config.properties file in path of your preference.
Set an environment variable PATH_CONFIG pointing to configuration file.
Start Tomcat server
Access in your browser to url http://IP:port/FileManager
Configure Tomcat to run when machine starts.

--Node for UnaCloud application

Install Java 7
Install and configure Tomcat 8
Allow communication by HTTP in configured port for Tomcat.
Allocate file UnaCloud.war in webapps Tomcat folder.
Set URL in config.properties file.
Allocate config.properties file in path of your preference.
Set an environment variable PATH_CONFIG pointing to configuration file.
Start Tomcat server
Access in your browser to url http://IP:port/UnaCloud
Configure Tomcat to run when machine starts.
Log in with user "Admin" and default password setted in config.properties file.