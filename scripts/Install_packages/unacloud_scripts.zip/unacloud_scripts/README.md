UnaCloud
Departamento de Ingenier�a de Sistemas y Computaci�n
Universidad de Los Andes
Colombia
https://github.com/UnaCloud

Quick Script-based Installation

This kind of installation is very fast and does not use distributed components. 
Download package for Script-based Installation, scripts are designed to run in Ubuntu (12 or better) or Debian (6 or better), don't forget to check system requeriments.

* Install SSH server to allow access to server
* Unzip package in path of your preference.
* Choose repository folder. We recommend a folder with restricted execution privileges (recommend /opt/unacloud/repo)
* Update config.properties file. Check pre-configuration section in Github.
* Set environment variable PATH_CONFIG pointed to config.properties file path or replace it in install.sh script
* Execute file install.sh
* The script will install in machine:
	Java 7
	Apache Tomcat 8
	UnaCloud app
	MySQL Database
	RabbitMQ
* Access in your browser to url http://IP:port/UnaCloud (Use IP address configured in config.properties file)
* Log in with user defined in config.properties file.
* Enjoy