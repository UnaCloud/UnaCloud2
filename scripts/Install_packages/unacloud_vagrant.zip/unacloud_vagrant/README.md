UnaCloud
Departamento de Ingenier�a de Sistemas y Computaci�n
Universidad de Los Andes
Colombia
https://github.com/UnaCloud

Quick Installation using Vagrant

This kind of installation is very fast, does not use distributed components and does not need a previous configured machine for server. 
Download package for Vagrant Installation, this installation will run in a virtual machine therefore your host machine should meet system requeriments.

* Install Vagrant from https://www.vagrantup.com/
* Install VirtualBox 5 or better.
* Unzip package in path of your preference.
* Replace IP_FOR_UNACLOUD word in vagrantfile by the IP address you defined for UnaCloud Server
* Replace IP_FOR_UNACLOUD word in fields WEB_SERVER_URL, WEB_FILE_SERVER_URL, CONTROL_SERVER_IP and FILE_SERVER_IP in config.properties, by the IP address you defined for UnaCloud Server
* Execute in terminal vagrantfile located in folder using command:

		vagrant up

* Can access to virtual machine using command:

		vagrant ssh

* Vagrant will configure machine with:
	* Java 7
	* Apache Tomcat 8
	* UnaCloud Server components
	* MySQL Database
	* RabbitMQ
* Access in your browser to url http://IP_FOR_UNACLOUD:8080/UnaCloud
* Log in with user admin and change password in profile segment